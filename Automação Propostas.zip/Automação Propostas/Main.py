import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
import os

class ConfigLoader:
    """Carrega as configurações de um arquivo de propriedades."""
    def __init__(self, config_file):
        self.config = {}
        self._load_config(config_file)

    def _load_config(self, file_path):
        """Lê o arquivo de propriedades e armazena em um dicionário."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Arquivo de configuração '{file_path}' não encontrado.")
        with open(file_path, 'r', encoding='iso-8859-1') as file:
            for line in file:
                if '=' in line and not line.startswith('#'):
                    key, value = line.strip().split('=', 1)
                    self.config[key] = value

    def get(self, key, default=None):
        """Obtém o valor de uma configuração, ou retorna um valor padrão."""
        return self.config.get(key, default)

def load_proposals(file_path):
    """Carrega os números das propostas de um arquivo."""
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Arquivo de propostas '{file_path}' não encontrado.")

    proposals = []
    with open(file_path, 'r', encoding='iso-8859-1') as file:
        for line in file:
            proposals.append(line.strip())
    return proposals

def find_element(driver, by, value):
    """Localiza um elemento com retries."""
    count = 1
    max_count = 10
    element = None
    while count < max_count:
        try:
            time.sleep(0.5)
            element = driver.find_element(by, value)
            element.click()
            break
        except Exception:
            count += 1
    return element

def insert_proposal_data(driver, proposal, config):
    """Insere dados da proposta."""
    txt_proposal = driver.find_element(By.NAME, "ctl00$Cph$txtNrProp$CAMPO")
    txt_proposal.send_keys(proposal)

    txt_client_name = find_element(driver, By.NAME, "ctl00$Cph$txtNomeCliente$CAMPO")
    txt_client_name.send_keys("")

    time.sleep(2)

    txt_return_to = find_element(driver, By.NAME, "ctl00$Cph$cboAtv$CAMPO")
    txt_return_to.send_keys(config.get("PHASE_DESTINO"))

    btn_confirm = find_element(driver, By.ID, "btnConfirmar_txt")
    btn_confirm.click()

    insert_note(driver, config)

    print(f"[{proposal}] Proposta retornada no fluxo com sucesso")

def insert_note(driver, config):
    """Insere a nota no sistema."""
    driver_wait = WebDriverWait(driver, 10)
    driver_wait.until(EC.visibility_of_element_located((By.NAME, "ctl00$Cph$UcObs1$txtObsNew$CAMPO")))

    txt_note = driver.find_element(By.NAME, "ctl00$Cph$UcObs1$txtObsNew$CAMPO")
    txt_note.send_keys(Keys.TAB)
    txt_note.clear()
    txt_note.send_keys(config.get("OBSERVATION"))

    btn_record = driver.find_element(By.ID, "btnGravar_txt")
    btn_record.click()

def go_return_workflow_page(driver):
    """Navega para a página de retorno de fluxo."""
    driver_wait = WebDriverWait(driver, 5)
    driver_wait.until(EC.visibility_of_element_located((By.XPATH, "//a[text()='Esteira ']")))

    menu = driver.find_element(By.XPATH, "//a[text()='Esteira ']")
    print(menu.text)

    action = ActionChains(driver)
    action.move_to_element(menu).perform()

    driver_wait.until(EC.visibility_of_element_located((By.XPATH, "//a[text()='Retorno de Fluxo']")))

    btn_flow_return = driver.find_element(By.XPATH, "//a[text()='Retorno de Fluxo']")
    print(btn_flow_return.text)

    btn_flow_return.click()

def login(driver, config):
    """Realiza o login no sistema."""
    driver.get(config.get("URL_AUTORIZADOR_HOME"))

    WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.NAME, "EUsuario$CAMPO"))
    )

    txt_user = driver.find_element(By.NAME, "EUsuario$CAMPO")
    txt_user.send_keys(config.get("USER"))

    txt_password = driver.find_element(By.NAME, "ESenha$CAMPO")
    txt_password.send_keys(config.get("PASSWORD"))

    btn_enter = driver.find_element(By.ID, "lnkEntrar")
    btn_enter.click()

def main():
    """Função principal do programa."""
    config_path = "./src/test/resources/configs.properties"
    proposals_path = "./src/test/resources/proposals.properties"

    driver = None  # Variável para controlar o driver

    try:
        # Carregar configurações e propostas
        config_loader = ConfigLoader(config_path)
        proposals = load_proposals(proposals_path)

        # Configurar driver com webdriver_manager
        options = Options()
        options.add_argument("--start-maximized")
        driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

        # Executar o fluxo principal
        login(driver, config_loader)
        go_return_workflow_page(driver)

        # Loop para processar cada proposta
        for proposal in proposals:
            try:
                print(f"Processando proposta: {proposal}")
                insert_proposal_data(driver, proposal, config_loader)

                # Adicionar delay após processar cada proposta
                print(f"Finalizada proposta {proposal}. Aguardando 3 segundos antes de continuar...")
                time.sleep(3)  # Delay de 3 segundos
            except Exception as e:
                print(f"Erro ao processar a proposta {proposal}: {e}")

        print("Todas as propostas foram processadas com sucesso!")

    except Exception as e:
        print(f"Erro geral: {e}")
    finally:
        # Fechar o driver apenas após o processamento de todas as propostas
        if driver:
            print("Encerrando o navegador...")
            driver.quit()

if __name__ == "__main__":
    main()
